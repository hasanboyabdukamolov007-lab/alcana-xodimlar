# Alcana Xodimlar — Telegram Mini App

**Nomi:** Alcana-Xodimlar haqida maʼlumot  
**Tavsiya etilgan manzil:** `https://alcana-xodimlar.sslip.io` (yoki o‘zingizning hosting)

## 1. Mini Appni joylash (sslip.io yoki boshqa)

### Variant A — Oddiy hosting + sslip.io (agar serveringiz bo‘lsa)

1. Mini App fayllarini (`miniapp/` papkasi) serveringizga joylang.
2. sslip.io dan foydalaning:
   - Serveringiz IP manzilini oling (masalan `123.45.67.89`)
   - Brauzerda oching: `https://123-45-67-89.sslip.io`
   - Yoki o‘zingiz xohlagan nom: `alcana-xodimlar.sslip.io` ishlashi uchun IP ga mos DNS sozlang (sslip.io avtomatik IP asosida ishlaydi).

**Eng oson:**  
Agar serveringizda nginx/apache bo‘lsa, Mini Appni shu yerda oching va sslip.io manzilini ishlating.

### Variant B — Vercel (eng ishonchli)

1. [vercel.com](https://vercel.com) → New Project
2. `miniapp` papkasidagi fayllarni yuklang
3. Project name: `alcana-xodimlar`
4. Deploy → sizga `https://alcana-xodimlar.vercel.app` beradi

## 2. Botni ishga tushirish

```bash
cd bot
npm install
cp .env.example .env
```

`.env` faylini ochib to‘ldiring:

```env
BOT_TOKEN=sizning_haqiqiy_bot_tokeningiz
WEBAPP_URL=https://alcana-xodimlar.sslip.io
```

(yoki Vercel manzilingizni yozing)

Keyin:

```bash
npm start
```

## 3. BotFather sozlamasi

1. [@BotFather](https://t.me/BotFather) → `/mybots`
2. Botingizni tanlang
3. **Bot Settings** → **Menu Button** → **Configure menu button**
4. URL ga Mini App manzilingizni kiriting (`https://alcana-xodimlar.sslip.io` yoki Vercel)

## Tayyor!

Telegramda botga `/start` yozing → **Alcanа Xodimlar** tugmasi chiqadi.

---

Agar sslip.io da HTTPS muammo bo‘lsa (ba’zi holatlarda), Vercel ishlatishni tavsiya qilaman — u avtomatik SSL beradi.